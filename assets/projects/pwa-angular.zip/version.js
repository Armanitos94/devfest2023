const { gitDescribeSync } = require("git-describe");
const { version } = require("./package.json");
const { resolve, relative } = require("path");
const { writeFileSync } = require("fs-extra");
const replace = require("replace-in-file");

const gitInfo = gitDescribeSync({
    dirtyMark: false,
    dirtySemver: false
});

gitInfo.version = version;

var file = resolve(__dirname, "src", "environments", "version.ts");
writeFileSync(file,
    `// IMPORTANT: THIS FILE IS AUTO GENERATED! DO NOT MANUALLY EDIT OR CHECKIN!
/* tslint:disable */
export const version = ${JSON.stringify(gitInfo, null, 4)};
/* tslint:enable */
`, { encoding: "utf-8" });

console.log(`Wrote version info ${version} to ${relative(resolve(__dirname, ".."), file)}`);

file = resolve(__dirname, "ngsw-config.json");
const options = {
    files: file,
    from: /"version": "\d+.\d+.\d+"/g,
    to: `"version": "${version}"`,
};
replace.sync(options);

console.log(`Wrote version info ${version} to ${relative(resolve(__dirname, ".."), file)}`);
