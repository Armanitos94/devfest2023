import { Injectable } from "@angular/core";
import { CoreModule } from "../core.module";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Options } from "../options/options";
import { Translation } from "./translation";

@Injectable({
    providedIn: CoreModule
})
export class TranslateService {
    constructor(
        private httpClient: HttpClient,
        private options: Options
    ) {
    }

    async translate(text: string): Promise<string> {
        const headers = new HttpHeaders()
            .append("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
            ;

        const body = new HttpParams()
            .set("key", this.options.translateApiKey)
            .set("text", text)
            .set("lang", "en-ru")
            .set("format", "plain")
            ;

        const result = await this.httpClient
            .post<Translation>(
                "https://translate.yandex.net/api/v1.5/tr.json/translate",
                body,
                {
                    headers
                })
            .toPromise()
            .then(translation => translation.text);

        return result;
    }
}
