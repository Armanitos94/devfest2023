export class Translation {
    lang: string;
    text: string;
}
