export class AppData {
    version: string;
}
