export enum AlertType {
    primary = "primary",
    success = "success",
    secondary = "secondary"
}
