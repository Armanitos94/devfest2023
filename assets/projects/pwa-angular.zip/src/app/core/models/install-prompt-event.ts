export interface InstallPromptEvent extends Event {
    prompt(): void;
}
