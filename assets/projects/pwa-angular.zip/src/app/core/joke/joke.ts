export class Joke {
    value: string;
}
