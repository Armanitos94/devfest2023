import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { CoreModule } from "../core.module";
import { Joke } from "./joke";

@Injectable({
    providedIn: CoreModule
})
export class JokeService {
    constructor(
        private httpClient: HttpClient
    ) {
    }

    async get(): Promise<string> {
        let result: string;

        const response = await this.httpClient
            .get<Joke>("https://api.chucknorris.io/jokes/random?category=dev")
            .toPromise();

        result = response.value;

        return result;
    }
}
