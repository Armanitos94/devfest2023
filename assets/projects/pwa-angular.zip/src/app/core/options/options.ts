export class Options {
    translateApiKey: string;
}
