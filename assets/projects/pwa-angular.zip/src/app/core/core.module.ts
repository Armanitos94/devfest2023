import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { Options } from "./options/options";
import { environment } from "../../environments/environment";
import { BrowserModule } from "@angular/platform-browser";

@NgModule({
    declarations: [
    ],
    exports: [
        BrowserModule,
        CommonModule
    ],
    imports: [
        BrowserModule,
        CommonModule,
        HttpClientModule
    ],
    providers: [
        { provide: Options, useValue: environment.options }
    ]
})
export class CoreModule {
}
