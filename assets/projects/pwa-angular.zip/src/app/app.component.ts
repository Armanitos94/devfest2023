import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { SwUpdate } from "@angular/service-worker";
import { JokeService } from "./core/joke/joke.service";
import { TranslateService } from "./core/translate/translate.service";
import { version } from "../environments/version";
import { AppData } from "./core/models/app-data";
import { Alert } from "./core/models/alert";
import { AlertType } from "./core/models/alert-type";
import { NgbModal, NgbModalConfig } from "@ng-bootstrap/ng-bootstrap";
import { InstallPromptEvent } from "./core/models/install-prompt-event";

@Component({
    selector: "app-root",
    templateUrl: "app.component.html",
    styleUrls: ["app.component.scss"]
})
export class AppComponent implements OnInit {
    joke: string;
    translatedJoke: string;
    loading = false;
    version = version.version;
    updateAvailable = false;
    alerts: Alert[] = [];
    deferredInstallPrompt: Event;
    installAvailable = false;

    @ViewChild("installConfirmModal") installConfirmModal: ElementRef;
    @ViewChild("installAvailableModal") installAvailableModal: ElementRef;

    constructor(
        private jokeService: JokeService,
        private translateService: TranslateService,
        private swUpdate: SwUpdate,
        private modalService: NgbModal,
        private config: NgbModalConfig
    ) {
    }

    async ngOnInit(): Promise<void> {
        this.subscribeOnInstallAvailable();

        this.config.backdrop = "static";

        await this.newJoke();

        this.swUpdate.available.subscribe(event => {
            const currentAppData = event.current.appData as AppData;
            const availableAppData = event.available.appData as AppData;

            this.addAlert(AlertType.secondary, `Available update to ${availableAppData.version}. Current is ${currentAppData.version}`);

            this.updateAvailable = true;
        });

        this.swUpdate.activated.subscribe(event => {
            const currentAppData = event.current.appData as AppData;

            this.addAlert(AlertType.primary, `Activated ${currentAppData.version}. Reloading...`);

            setTimeout(() => {
                document.location.reload();
            }, 2000);
        });
    }

    async checkForUpdate(): Promise<void> {
        await this.swUpdate.checkForUpdate();
    }

    async forceUpdate(): Promise<void> {
        await this.swUpdate.activateUpdate();
    }

    async newJoke(): Promise<void> {
        if (!this.loading) {
            this.loading = true;

            this.joke = await this.jokeService.get();
            this.translatedJoke = await this.translateService.translate(this.joke);

            this.loading = false;
        }
    }

    closeAlert(alert: Alert): void {
        this.alerts.splice(this.alerts.indexOf(alert), 1);
    }

    private addAlert(type: AlertType, message: string): void {
        const alert = {
            type,
            message
        };

        this.alerts.push(alert);

        setTimeout(() => {
            this.closeAlert(alert);
        }, 5000);
    }

    private subscribeOnInstallAvailable(): void {
        if ((navigator as any).standalone == false) {
            // This is an iOS device and we are in the browser
            this.modalService.open(this.installAvailableModal);
        }
        if ((navigator as any).standalone == undefined) {
            // It's not iOS
            if (window.matchMedia("(display-mode: browser").matches) {
                // We are in the browser
                window.addEventListener("beforeinstallprompt", async (event: InstallPromptEvent) => {
                    event.preventDefault();

                    const confirmResult = await this.modalService.open(this.installConfirmModal).result;

                    if (confirmResult) {
                        event.prompt();
                    }
                });
            }
        }
    }
}
