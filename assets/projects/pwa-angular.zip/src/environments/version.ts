// IMPORTANT: THIS FILE IS AUTO GENERATED! DO NOT MANUALLY EDIT OR CHECKIN!
/* tslint:disable */
export const version = {
    "dirty": true,
    "raw": "39fd857-dirty",
    "hash": "39fd857",
    "distance": null,
    "tag": null,
    "semver": null,
    "suffix": "39fd857-dirty",
    "semverString": null,
    "version": "0.0.28"
};
/* tslint:enable */
