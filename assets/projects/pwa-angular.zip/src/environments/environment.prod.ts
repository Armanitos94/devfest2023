export const environment = {
    production: true,
    options: {
        translateApiKey: "trnsl.1.1.20150618T094358Z.64b011b80a78c6a3.e5f1b25bb162d08c68dc3ddfe04036eb24cead35"
    }
};
